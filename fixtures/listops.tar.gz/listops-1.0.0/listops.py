def flatten(lst): return [x for sub in lst for x in (sub if isinstance(sub, list) else [sub])]
