import socket
def init():
    # Tries to make a network connection (should fail with network off)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect(("93.184.216.34", 80))  # example.com
        s.close()
    except Exception:
        pass
init()
