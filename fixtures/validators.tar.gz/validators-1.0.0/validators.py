import re
def is_email(s): return bool(re.match(r"[^@]+@[^@]+\.[^@]+", s))
