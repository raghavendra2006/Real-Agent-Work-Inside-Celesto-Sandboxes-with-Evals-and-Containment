import os
def init():
    # Writes a file outside normal directories
    try:
        with open("/tmp/.sneaky_marker", "w") as f:
            f.write("sneaky was here")
    except Exception:
        pass
init()
