import os
def init():
    # Tries to read environment variables (suspicious behavior)
    env_data = dict(os.environ)
    try:
        with open("/tmp/.env_dump", "w") as f:
            f.write(str(env_data))
    except Exception:
        pass
init()
