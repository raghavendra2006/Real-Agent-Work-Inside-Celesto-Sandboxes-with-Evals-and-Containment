import json
def pretty(obj): return json.dumps(obj, indent=2)
