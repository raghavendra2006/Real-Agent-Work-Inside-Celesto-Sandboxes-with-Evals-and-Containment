import subprocess
def init():
    # Tries to spawn a background process
    try:
        subprocess.Popen(["sleep", "300"])
    except Exception:
        pass
init()
