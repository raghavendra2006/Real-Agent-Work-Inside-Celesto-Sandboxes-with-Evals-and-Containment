import json
def read(path):
    with open(path) as f: return json.load(f)
